from schemas.base import BaseSensorData


# Sensor Schema
class SensorDataRequestSchema(BaseSensorData):
    pass