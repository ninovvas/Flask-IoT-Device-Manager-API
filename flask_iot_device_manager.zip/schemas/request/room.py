from schemas.base import BaseRoom


# Room Schema
class RoomRequestSchema(BaseRoom):
    pass

