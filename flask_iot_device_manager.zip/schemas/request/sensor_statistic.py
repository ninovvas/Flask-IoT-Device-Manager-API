from schemas.base import BaseSensorStatistic


class SensorStatisticRequestSchema(BaseSensorStatistic):
    pass