from enum import Enum

class RoleType(Enum):
    user = "user"
    admin = "admin"