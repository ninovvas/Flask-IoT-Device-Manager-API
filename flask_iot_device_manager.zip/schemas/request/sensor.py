from schemas.base import BaseSensor

# Sensor Schema
class SensorRequestSchema(BaseSensor):
    pass