from schemas.base import BaseSensorSchedule

class SensorScheduleRequestSchema(BaseSensorSchedule):
    pass